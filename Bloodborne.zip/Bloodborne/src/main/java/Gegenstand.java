public class Gegenstand {
    private String name; // Der Name des Gegenstands
    private String typ;  // Der Typ des Gegenstands (z.B. Waffe, Heilung, Gegner)

    // Konstruktor, der den Namen und den Typ des Gegenstands initialisiert
    public Gegenstand(String name, String typ) {
        this.name = name;
        this.typ = typ;
    }

    // Methode, um den Namen des Gegenstands zu erhalten
    public String getName() {
        return name;
    }

    // Methode, um den Typ des Gegenstands zu erhalten
    public String getTyp() {
        return typ;
    }
}