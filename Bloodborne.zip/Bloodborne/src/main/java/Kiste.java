import java.util.ArrayList;
import java.util.List;

public class Kiste {
    private String name; // Der Name der Kiste
    private List<Gegenstand> gegenstaende; // Die Liste der Gegenstände in der Kiste

    // Konstruktor, der den Namen der Kiste initialisiert und die Liste der Gegenstände erstellt
    public Kiste(String name) {
        this.name = name;
        this.gegenstaende = new ArrayList<>();
    }

    // Methode zum Hinzufügen eines Gegenstands zur Kiste
    public void addGegenstand(Gegenstand gegenstand) {
        gegenstaende.add(gegenstand);
    }

    // Methode zum Abrufen der Liste der Gegenstände in der Kiste
    public List<Gegenstand> getGegenstaende() {
        return gegenstaende;
    }

    // Methode zum Abrufen des Namens der Kiste
    public String getName() {
        return name;
    }
}