import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Raum {
    private String name; // Der Name des Raums
    private String beschreibung; // Die Beschreibung des Raums
    private Map<String, Raum> nachbarn; // Die Nachbarräume
    private List<Kiste> kisten; // Die Kisten im Raum

    // Konstruktor, der den Namen und die Beschreibung des Raums initialisiert
    public Raum(String name, String beschreibung) {
        this.name = name;
        this.beschreibung = beschreibung;
        this.nachbarn = new HashMap<>();
        this.kisten = new ArrayList<>();
    }

    // Methode zum Setzen eines Nachbarraums in einer bestimmten Richtung
    public void setNachbar(String richtung, Raum raum) {
        nachbarn.put(richtung, raum);
    }

    // Methode zum Abrufen eines Nachbarraums in einer bestimmten Richtung
    public Raum getNachbar(String richtung) {
        return nachbarn.get(richtung);
    }

    // Methode zum Hinzufügen einer Kiste zum Raum
    public void addKiste(Kiste kiste) {
        kisten.add(kiste);
    }

    // Methode zum Abrufen der Kisten im Raum
    public List<Kiste> getKisten() {
        return kisten;
    }

    // Methode zum Abrufen des Namens des Raums
    public String getName() {
        return name;
    }

    // Methode zum Abrufen der Beschreibung des Raums
    public String getBeschreibung() {
        return beschreibung;
    }
}