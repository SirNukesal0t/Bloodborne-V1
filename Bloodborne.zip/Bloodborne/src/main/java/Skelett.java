public class Skelett extends Gegenstand {
    private int leben; // Die Lebenspunkte des Skeletts

    // Konstruktor, der den Namen, die Lebenspunkte und den Typ des Skeletts initialisiert
    public Skelett(String name, int leben) {
        super(name, "Gegner");
        this.leben = leben;
    }

    // Methode, um dem Skelett Schaden zuzufügen
    public void schaden(int menge) {
        leben -= menge;
    }

    // Methode, um die aktuellen Lebenspunkte des Skeletts zu erhalten
    public int getLeben() {
        return leben;
    }
}