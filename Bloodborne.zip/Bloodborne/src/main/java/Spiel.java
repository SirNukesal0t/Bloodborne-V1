import javax.swing.*;
import java.awt.*;
import java.util.Scanner;
import java.util.ArrayList;

public class Spiel {
    private Spieler spieler; // Der Spieler des Spiels
    private Raum aktuellerRaum; // Der aktuelle Raum, in dem sich der Spieler befindet

    // Konstruktor, der den Spieler initialisiert und die Räume erstellt
    public Spiel() {
        spieler = new Spieler("Spieler");
        initialisiereRaeume();
    }

    // Methode zur Initialisierung der Räume und deren Nachbarn
    private void initialisiereRaeume() {
        Raum josefkasKlinik = new Raum("Josefkas Klinik", "Du bist in Josefkas Klinik.");
        Raum centralYharnam = new Raum("Central Yharnam", "Du bist in Central Yharnam.");
        Raum oldYharnam = new Raum("Old Yharnam", "Du bist in Old Yharnam.");
        Raum forbiddenWoods = new Raum("Forbidden Woods", "Du bist in Forbidden Woods.");
        Raum cathedralWard = new Raum("Cathedral Ward", "Du bist in Cathedral Ward.");
        Raum hemwickCharnalLane = new Raum("Hemwick Charnal Lane", "Du bist in Hemwick Charnal Lane.");
        Raum byrgenwerth = new Raum("Byrgenwerth", "Du bist in Byrgenwerth.");
        Raum forsakenCastleCainhurst = new Raum("Forsaken Castle Cainhurst", "Du bist in Forsaken Castle Cainhurst.");

        // Setzen der Nachbarn für die Räume
        josefkasKlinik.setNachbar("rechts", centralYharnam);
        centralYharnam.setNachbar("links", josefkasKlinik);

        centralYharnam.setNachbar("unten", oldYharnam);
        oldYharnam.setNachbar("oben", centralYharnam);

        centralYharnam.setNachbar("rechts", forbiddenWoods);
        forbiddenWoods.setNachbar("links", centralYharnam);

        centralYharnam.setNachbar("oben", cathedralWard);
        cathedralWard.setNachbar("unten", centralYharnam);

        forbiddenWoods.setNachbar("rechts", byrgenwerth);
        byrgenwerth.setNachbar("links", forbiddenWoods);

        byrgenwerth.setNachbar("oben", forsakenCastleCainhurst);
        forsakenCastleCainhurst.setNachbar("unten", byrgenwerth);

        cathedralWard.setNachbar("rechts", hemwickCharnalLane);
        hemwickCharnalLane.setNachbar("links", cathedralWard);

        hemwickCharnalLane.setNachbar("rechts", forsakenCastleCainhurst);
        forsakenCastleCainhurst.setNachbar("links", hemwickCharnalLane);

        // Hinzufügen von Kisten zu den Räumen
        Kiste kiste1 = new Kiste("Kiste1");
        kiste1.addGegenstand(new Gegenstand("Sägespeer", "Waffe"));
        josefkasKlinik.addKiste(kiste1);

        Kiste kiste2 = new Kiste("Kiste2");
        kiste2.addGegenstand(new Gegenstand("Blutphiole", "Heilung"));
        centralYharnam.addKiste(kiste2);

        Kiste kiste3 = new Kiste("Kiste3");
        kiste3.addGegenstand(new Skelett("Skelett", 50));
        centralYharnam.addKiste(kiste3);

        Kiste kiste4 = new Kiste("Kiste4");
        kiste4.addGegenstand(new Skelett("Skelett", 50));
        oldYharnam.addKiste(kiste4);

        Kiste kiste5 = new Kiste("Kiste5");
        kiste5.addGegenstand(new Gegenstand("Blutphiole", "Heilung"));
        oldYharnam.addKiste(kiste5);

        Kiste kiste6 = new Kiste("Kiste6");
        kiste6.addGegenstand(new Gegenstand("Blutphiole", "Heilung"));
        forbiddenWoods.addKiste(kiste6);

        Kiste kiste7 = new Kiste("Kiste7");
        kiste7.addGegenstand(new Skelett("Skelett", 50));
        byrgenwerth.addKiste(kiste7);

        Kiste kiste8 = new Kiste("Kiste8");
        kiste8.addGegenstand(new Skelett("Shkeleton", 120));
        forsakenCastleCainhurst.addKiste(kiste8);

        Kiste kiste9 = new Kiste("Kiste9");
        kiste9.addGegenstand(new Skelett("Skelett", 50));
        hemwickCharnalLane.addKiste(kiste9);

        Kiste kiste10 = new Kiste("Kiste10");
        kiste10.addGegenstand(new Gegenstand("Blutphiole", "Heilung"));
        hemwickCharnalLane.addKiste(kiste10);

        Kiste kiste11 = new Kiste("Kiste11");
        kiste11.addGegenstand(new Skelett("Skelett", 50));
        hemwickCharnalLane.addKiste(kiste11);

        aktuellerRaum = josefkasKlinik; // Setzen des Startraums
    }

    // Hauptspielschleife, die Benutzereingaben verarbeitet und Aktionen ausführt
    private void spielen() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println(aktuellerRaum.getBeschreibung());
                zeigeRaumInhalt();
                System.out.println("Was möchtest du tun?");
                String aktion = scanner.nextLine();
                if (aktion.startsWith("gehe ")) {
                    gehe(aktion.split(" ")[1]);
                } else if (aktion.startsWith("öffne ")) {
                    interagiere(aktion.split(" ")[1]);
                } else if (aktion.equals("help")) {
                    zeigeHilfe();
                } else if (aktion.equals("karte")) {
                    zeigeKarte();
                } else if (aktion.equals("inventar") || aktion.equals("i")) {
                    zeigeInventar();
                } else {
                    System.out.println("Ungültige Aktion.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Ein Fehler ist aufgetreten: " + e.getMessage());
            }
        }
    }

    // Methode zum Bewegen des Spielers in eine angegebene Richtung
    private void gehe(String richtung) {
        if (aktuellerRaum.getNachbar(richtung) != null) {
            aktuellerRaum = aktuellerRaum.getNachbar(richtung);
        } else {
            System.out.println("Da ist keine Tür nach " + richtung + ".");
        }
    }

    // Methode zur Interaktion mit einer Kiste im aktuellen Raum
    private void interagiere(String objekt) {
        for (Kiste kiste : aktuellerRaum.getKisten()) {
            if (kiste.getName().equalsIgnoreCase(objekt)) {
                System.out.println("Du öffnest " + kiste.getName() + " und findest:");
                for (Gegenstand g : new ArrayList<>(kiste.getGegenstaende())) {
                    System.out.println("- " + g.getName() + " (" + g.getTyp() + ")");
                    if (g.getTyp().equals("Gegner")) {
                        kaempfen((Skelett) g);
                    } else {
                        spieler.addGegenstand(g);
                        kiste.getGegenstaende().remove(g);
                    }
                }
                return;
            }
        }
        System.out.println("Es gibt keine " + objekt + " hier.");
    }

    // Methode zur Anzeige des Inhalts des aktuellen Raums
    private void zeigeRaumInhalt() {
        System.out.println("Im Raum gibt es:");
        for (Kiste kiste : aktuellerRaum.getKisten()) {
            System.out.println("- " + kiste.getName());
        }
    }

    // Methode zur Anzeige der verfügbaren Befehle
    private void zeigeHilfe() {
        System.out.println("Verfügbare Commands:");
        System.out.println("gehe <richtung> - rechts, links, oben, unten|Um sich zu bewegen.");
        System.out.println("öffne <Kiste> - Öffnet die angegebene Kiste.");
        System.out.println("help - Zeigt die verfügbaren Commands.");
        System.out.println("karte - Zeigt in welche richtung du gehen kannst.");
        System.out.println("inventar oder i - Öffnet das inventar.");
    }

    // Methode zur Anzeige der Karte des aktuellen Raums und seiner Nachbarn
    private void zeigeKarte() {
        System.out.println("Du bist in " + aktuellerRaum.getName());
        System.out.println("Mögliche Richtungen:");
        if (aktuellerRaum.getNachbar("rechts") != null) {
            System.out.println("rechts: " + aktuellerRaum.getNachbar("rechts").getName());
        }
        if (aktuellerRaum.getNachbar("unten") != null) {
            System.out.println("unten: " + aktuellerRaum.getNachbar("unten").getName());
        }
        if (aktuellerRaum.getNachbar("oben") != null) {
            System.out.println("oben: " + aktuellerRaum.getNachbar("oben").getName());
        }
        if (aktuellerRaum.getNachbar("links") != null) {
            System.out.println("links: " + aktuellerRaum.getNachbar("links").getName());
        }
    }

    // Methode zur Anzeige des Inventars des Spielers in einem neuen Fenster
    private void zeigeInventar() {
        JFrame frame = new JFrame("Inventar");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(500, 400);

        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (Gegenstand g : spieler.getInventar()) {
            listModel.addElement(g.getName() + " (" + g.getTyp() + ")");
        }

        JList<String> list = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        JButton mapButton = new JButton("Map anzeigen");
        mapButton.addActionListener(e -> {
            String imgPath = "C:\\2.Jahr_1.Semester\\Modul 320\\Projects\\Bloodborne\\src\\karte.jpg";
            ImageIcon karteIcon = new ImageIcon(imgPath);
            JLabel karteLabel = new JLabel(karteIcon);

            JFrame mapFrame = new JFrame("Karte");
            mapFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            mapFrame.setSize(1600, 1600);
            mapFrame.add(karteLabel);
            mapFrame.setVisible(true);
        });

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(mapButton, BorderLayout.SOUTH);

        frame.add(panel);
        frame.setVisible(true);
    }

    // Methode zum Kämpfen gegen ein Skelett
    private void kaempfen(Skelett gegner) {
        Scanner scanner = new Scanner(System.in);
        boolean blocken = false;
        while (spieler.getLeben() > 0 && gegner.getLeben() > 0) {
            System.out.println("Du kämpfst gegen " + gegner.getName() + ". Was möchtest du tun? (angreifen, heilen, blocken)");
            if (gegner.getName().equals("Shkeleton")) {
                System.out.println("              .7\n" +
                        "            .' /\n" +
                        "           / /\n" +
                        "          / /\n" +
                        "         / /\n" +
                        "        / /\n" +
                        "       / /\n" +
                        "      / /\n" +
                        "     / /\n" +
                        "    / /\n" +
                        "  __|/\n" +
                        ",-\\__\\\n" +
                        "|f-\"Y\\|\n" +
                        "\\()7L/\n" +
                        " cgD                            __ _\n" +
                        " |\\(                          .'  Y '>,\n" +
                        "  \\ \\                        / _   _   \\\n" +
                        "   \\\\\\                       )(_) (_)(|}\n" +
                        "    \\\\\\                      {  4A   } /\n" +
                        "     \\\\\\                      \\uLuJJ/\\l\n" +
                        "      \\\\\\                     |3    p)/\n" +
                        "       \\\\\\___ __________      /nnm_n//\n" +
                        "       c7___-__,__-),__)\".  \\_>-<_/D\n" +
                        "                  //V     \\_\"-._.__G G_c__.-__<\"/ ( \\\n" +
                        "                         <\"-._>__-,G_.___)\\   \\7\\\n" +
                        "                        (\"-.__.| \"<.__.-\" )   \\ \\\n" +
                        "                        |\"-.__\"\\  |\"-.__.-\".\\   \\ \\\n" +
                        "                        (\"-.__\"\". \"-.__.-\".|    \\_\\\n" +
                        "                        \"-.__\"\"|!|\"-.__.-\".)     \\ \\\n" +
                        "                         \"-.__\"\"\\_|\"-.__.-\"./      \\ l\n" +
                        "                          \"-.__\"\">G>-.__.-\">       .--,_\n" +
                        "                              \"\"  G");
            } else {
                System.out.println("                               _.--\"\"-._\n" +
                        "  .                         .\"         \".\n" +
                        " / \\    ,^.         /(     Y             |      )\\\n" +
                        "/   `---. |--'\\    (  \\__..'--   -   -- -'\"\"-.-'  )\n" +
                        "|        :|    `>   '.     l_..-------.._l      .'\n" +
                        "|      __l;__ .'      \"-.__.||_.-'v'-._||`\"----\"\n" +
                        " \\  .-' | |  `              l._       _.'\n" +
                        "  \\/    | |                   l`^^'^^'j\n" +
                        "        | |                _   \\_____/     _\n" +
                        "        j |               l `--__)-'(__.--' |\n" +
                        "        | |               | /`---``-----'\"1 |  ,-----.\n" +
                        "        | |               )/  `--' '---'   \\'-'  ___  `-.\n" +
                        "        | |              //  `-'  '`----'  /  ,-'   I`.  \\\n" +
                        "      _ L |_            //  `-.-.'`-----' /  /  |   |  `. \\\n" +
                        "     '._' / \\         _/(   `/   )- ---' ;  /__.J   L.__.\\ :\n" +
                        "      `._;/7(-.......'  /        ) (     |  |            | |\n" +
                        "      `._;l _'--------_/        )-'/     :  |___.    _._./ ;\n" +
                        "        | |                 .__ )-'\\  __  \\  \\  I   1   / /\n" +
                        "        `-'                /   `-\\-(-'   \\ \\  `.|   | ,' /\n" +
                        "                           \\__  `-'    __/  `-. `---'',-'\n" +
                        "                              )-._.-- (        `-----'\n" +
                        "                             )(  l\\ o ('..-.\n" +
                        "                       _..--' _'-' '--'.-. |\n" +
                        "                __,,-'' _,,-''            \\ \\\n" +
                        "               f'. _,,-'                   \\ \\\n" +
                        "              ()--  |                       \\ \\\n" +
                        "                \\.  |                       /  \\\n" +
                        "                  \\ \\                      |._  |\n" +
                        "                   \\ \\                     |  ()|\n" +
                        "                    \\ \\                     \\  /\n" +
                        "                     ) `-.                   | |\n" +
                        "                    // .__)                  | |\n" +
                        "                 _.//7'                      | |\n" +
                        "               '---'                         j_| `\n" +
                        "                                            (| |\n" +
                        "                                             |  \\\n" +
                        "                                             |lllj\n" +
                        "                                             |||||");
            }
            String aktion = scanner.nextLine();
            if (aktion.equals("angreifen")) {
                System.out.println("Du greifst an.");
                gegner.schaden(10);
                System.out.println(gegner.getName() + " hat jetzt " + gegner.getLeben() + " Leben.");
                blocken = false;
            } else if (aktion.equals("heilen")) {
                if (spieler.getInventar().stream().anyMatch(i -> i.getTyp().equals("Heilung"))) {
                    spieler.heilen(70);
                    System.out.println("Du hast dich geheilt. Du hast jetzt " + spieler.getLeben() + " Leben.");
                } else {
                    System.out.println("Keine Heilgegenstände verfügbar.");
                }
                blocken = false;
            } else if (aktion.equals("blocken")) {
                System.out.println("Du blockst den Angriff.");
                blocken = true;
            } else {
                System.out.println("Ungültige Aktion.");
                blocken = false;
            }

            if (gegner.getLeben() > 0) {
                System.out.println(gegner.getName() + " greift dich an.");
                int schaden = gegner.getName().equals("Shkeleton") ? 20 : 10;
                if (blocken) {
                    schaden /= 2;
                }

                spieler.schaden(schaden);
                System.out.println("Du hast jetzt " + spieler.getLeben() + " Leben.");
            }
        }

        if (spieler.getLeben() <= 0) {
            System.out.println("Du bist gestorben.");
        } else if (gegner.getLeben() <= 0) {
            System.out.println("Du hast " + gegner.getName() + " besiegt.");
            if (gegner.getName().equals("Endboss")) {
                System.out.println("Herzlichen Glückwunsch! Du hast das Spiel gewonnen!");
                System.exit(0); // Beendet das Spiel
            }
        }
    }

    // Hauptmethode zum Starten des Spiels
    public static void main(String[] args) {
        Spiel spiel = new Spiel();
        spiel.spielen();
    }
}