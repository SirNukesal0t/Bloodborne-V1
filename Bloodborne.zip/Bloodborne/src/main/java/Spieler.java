import java.util.ArrayList;

public class Spieler {
    private String name; // Der Name des Spielers
    private int leben; // Die Lebenspunkte des Spielers
    private ArrayList<Gegenstand> inventar; // Das Inventar des Spielers

    // Konstruktor, der den Namen des Spielers initialisiert und die Lebenspunkte auf 100 setzt
    public Spieler(String name) {
        this.name = name;
        this.leben = 100;
        this.inventar = new ArrayList<>();
    }

    // Methode zum Hinzufügen eines Gegenstands zum Inventar
    public void addGegenstand(Gegenstand gegenstand) {
        inventar.add(gegenstand);
    }

    // Methode zum Heilen des Spielers um eine bestimmte Menge
    public void heilen(int menge) {
        for (Gegenstand g : inventar) {
            if (g.getTyp().equals("Heilung")) {
                inventar.remove(g);
                leben += menge;
                if (leben > 100) {
                    leben = 100;
                }
                break;
            }
        }
    }

    // Methode, um dem Spieler Schaden zuzufügen
    public void schaden(int menge) {
        leben -= menge;
    }

    // Methode, um die aktuellen Lebenspunkte des Spielers zu erhalten
    public int getLeben() {
        return leben;
    }

    // Methode, um das Inventar des Spielers zu erhalten
    public ArrayList<Gegenstand> getInventar() {
        return inventar;
    }
}